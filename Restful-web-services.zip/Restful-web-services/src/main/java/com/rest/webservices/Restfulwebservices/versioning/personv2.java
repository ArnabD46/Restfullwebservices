package com.rest.webservices.Restfulwebservices.versioning;

public class personv2 {
	private Name name;

	public personv2() {
		super();
	}

	public personv2(Name name) {
		super();
		this.name = name;
	}

	public Name getName() {
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}

}
