package com.rest.webservices.Restfulwebservices.exception;

import java.util.Date;

public class Exceptionresponse {
	private Date timestamp;
	private String message;
	private String detailS;
	
	
	public Exceptionresponse(Date timestamp, String message, String detailS) {
		super();
		this.timestamp = timestamp;
		this.message = message;
		this.detailS = detailS;
	}
	public Date getTimestamp() {
		return timestamp;
	}
	public String getMessage() {
		return message;
	}
	public String getDetailS() {
		return detailS;
	}
	
}
